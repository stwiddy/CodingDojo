function like1() {
    document.querySelector("#neil");
    neil.innerText = "10 like(s)"
}

function like2() {
    document.querySelector("#nic");
    nic.innerText = "13 like(s)"
}

function like3() {
    document.querySelector("#jim");
    jim.innerText = "10 like(s)"
}