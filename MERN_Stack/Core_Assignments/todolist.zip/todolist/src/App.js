import './App.css';
import TodoListCon from './components/TodoListCon';


function App() {
    return (
        <div className="App">
            <TodoListCon />
        </div>
    );
}

export default App;