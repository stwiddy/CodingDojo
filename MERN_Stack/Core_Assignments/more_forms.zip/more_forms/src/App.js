import './App.css';
import UserForm from './components/userform';


function App() { 
  return ( 
      <div className="App"> 
          <UserForm />
      </div> 
  ); 
} 

export default App;
